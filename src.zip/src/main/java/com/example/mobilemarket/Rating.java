package com.example.mobilemarket;

public class Rating {
    Double rating;

}
